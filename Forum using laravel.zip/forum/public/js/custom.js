
$('.slider6').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
    autoplaySpeed:700,
  prevArrow:'.prev',
  nextArrow:'.next',
  arrows: true,
    dots:true,

 
  
});