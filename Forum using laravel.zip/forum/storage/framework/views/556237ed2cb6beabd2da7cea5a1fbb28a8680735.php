<div class="container">

  <div class="fill">        
    <img src="http://www.athens.edu/images/coas/programs/computer-science.jpg?x75869" class="img-responsive" alt="Responsive image">
  </div>


</div>
