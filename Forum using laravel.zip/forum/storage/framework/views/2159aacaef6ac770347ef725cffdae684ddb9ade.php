<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/slick.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>" />
</head>
<body>
<div class="full-wrapper slider">
  
  
  <div class="slider6" style=" background:#85929E">
    <div class="img-slider" >
      <div class="wrapper">
        <div class="text-slider">
          <h2>Artificial Intelligence</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, consequatur exercitationem fugit minima quis ex!</p>

        </div>
      </div>
    </div>
    <div class="img-slider" style="background: url(images/banner2.jpg)">
      <div class="wrapper">
        <div class="text-slider">
          <h2>Web Development</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, consequatur exercitationem fugit minima quis ex!</p>

        </div>
      </div>
    </div>
    <div class="img-slider" style="background: url::asset('images/banner3.jpg')">
      <div class="wrapper">
        <div class="text-slider">
          <h2>Web Design</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, consequatur exercitationem fugit minima quis ex!</p>
        </div>
      </div>
    </div>
    <div class="img-slider" style="background: url::asset('images/banner3.jpg')">
      <div class="wrapper">
        <div class="text-slider">
          <h2>Software Develop</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, consequatur exercitationem fugit minima quis ex!</p>
        </div>
      </div>
    </div>
    <div class="img-slider" style="background: url::asset('images/banner3.jpg')">
      <div class="wrapper">
        <div class="text-slider">
          <h2>Game Design</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, consequatur exercitationem fugit minima quis ex!</p>
        </div>
      </div>
    </div>


  </div>
</div>
<script type="text/javascript" src="<?php echo e(url::asset('js/jquery-1.12.4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url::asset('js/slick.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url::asset('js/custom.js')); ?>"></script>
</body>
</html>
