<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
  <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet" type="text/css" >
</head>
<body>
<div class="nav-scroller py-1 mb-2 ">
  <nav class="nav d-flex justify-content-between">
    <a class="p-2 text-muted" href="/home">Home</a>
    <a class="p-2 text-muted" href="/">Posts</a>
    <a class="p-2 text-muted" href="/posts/create">Create Post</a>
    <a class="p-2 text-muted" href="/problems">Problems</a>
    <a class="p-2 text-muted" href="/about">About</a>

  </nav>
</div>
</body>
</html>