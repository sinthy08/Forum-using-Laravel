<div class="blog-post">
  <h3>
    <a href="/posts/<?php echo e($post->id); ?>">
      <?php echo e($post->title); ?>

    </a>
  </h3>


  <p class="blog-post-meta">
  	<?php echo e($post->user->name); ?> on
    <?php echo e($post->created_at->toFormattedDateString()); ?>

  </p>
  <p> <?php echo e($post->body); ?> </p>
</div><!-- /.blog-post -->