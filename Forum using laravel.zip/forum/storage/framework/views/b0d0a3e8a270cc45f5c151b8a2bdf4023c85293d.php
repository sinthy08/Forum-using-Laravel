<footer class="blog-footer">
    <p>Personal Project by:<br><br> <a class="btn btn-sm btn-outline-secondary" href="/">Maknun</a> <a class="btn btn-sm btn-outline-secondary" href="/">Sinthia</a></p>
    <p>
    	<a href="#">Back to top</a>
    </p>
</footer>