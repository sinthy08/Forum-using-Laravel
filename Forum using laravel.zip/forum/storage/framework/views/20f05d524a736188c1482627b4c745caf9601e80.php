<aside class="col-md-4 blog-sidebar">
  <div class="p-3 mb-3 bg-light rounded">
    <h4 class="font-italic"><a href='/about'>About</a></h4>
    <p class="mb-0">This Forum is for the problem solvers.</p>
  </div>

  <div class="p-3">
    <h4 class="font-italic">Post Archives</h4>
    <ol class="list-unstyled mb-0">
      <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <a href="/?month=<?php echo e($stats['month']); ?>&year=<?php echo e($stats['year']); ?>">
            <?php echo e($stats['month'].' '.$stats['year']); ?>

          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
  </div>

  <div class="p-3">
    <h4 class="font-italic">Problem Tags</h4>
    <ol class="list-unstyled mb-0">
      <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <a href="/problems/tags/<?php echo e($tag); ?>">
            <?php echo e($tag); ?>

          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
  </div>
</aside><!-- /.blog-sidebar -->