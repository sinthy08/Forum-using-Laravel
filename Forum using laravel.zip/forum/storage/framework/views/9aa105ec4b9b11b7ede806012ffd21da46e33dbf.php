<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/header.css')); ?>" />

</head>
<body>
<div class="container">
    <header class="blog-header py-3">
        <div class="row ">
            <div class="col-12 sign">

                <?php if(Auth::check()): ?>
                    <a class="text-muted" href="#"><?php echo e(Auth::user()->name); ?></a>
                <?php endif; ?>

                <?php if(!(Auth::check())): ?>
                  <div class="button">
                      <a  href="/login">Login</a>
                      <a  href="/register">Register</a>
                      <a  href="/login">Admin</a>
                  </div>
                <?php endif; ?>
            </div>

            <div class="col-4 d-flex justify-content-end align-items-center">
                <?php if(Auth::check()): ?>
                    <a class="btn btn-sm btn-outline-secondary" href="/logout">Logout</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
</body>
</html>