<?php $__env->startSection('content'); ?>

	<div class="col-md-8">
		<table class="table table-hover">
			<tr>
				<th> Problem name </th>
				<th> Online Judge </th>
				<th> Problem Level </th>
			</tr>
			<?php $__currentLoopData = $problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td> <a href="<?php echo e($problem->link); ?>">
						<?php echo e($problem->name); ?></a> 
					</td>
					<td> <?php echo e($problem->oj_name); ?> </td>
					<td> <?php echo e($problem->level); ?> </td>
				<tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>