<div class="nav-scroller py-1 mb-2">
  <nav class="nav d-flex justify-content-between">
    <a class="p-2 text-muted" href="/home">Home</a>
    <a class="p-2 text-muted" href="/">Posts</a>
    <a class="p-2 text-muted" href="/posts/create">Create Post</a>
    <a class="p-2 text-muted" href="/problems">Problems</a>
    <a class="p-2 text-muted" href="/about">About</a>
    <!--<a class="p-2 text-muted" href="#">Business</a>
    <a class="p-2 text-muted" href="#">Politics</a>
    <a class="p-2 text-muted" href="#">Opinion</a>
    <a class="p-2 text-muted" href="#">Science</a>
    <a class="p-2 text-muted" href="#">Health</a>
    <a class="p-2 text-muted" href="#">Style</a>
    <a class="p-2 text-muted" href="#">Travel</a>-->
  </nav>
</div>